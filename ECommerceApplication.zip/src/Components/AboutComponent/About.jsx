import React from 'react'
import Main from '../HomeComponent/MainContent/Main'

const About = () => {

  const data = {
    name: "Cart Ecommerce"
  }

  return (
    <div>
      <Main myData={data}/>
    </div>
  )
}

export default About
