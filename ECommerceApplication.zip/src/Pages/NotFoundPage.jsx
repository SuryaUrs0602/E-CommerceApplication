import React from 'react'
import NotFound from '../Components/NotFoundComponent/NotFound'

const NotFoundPage = () => {
  return (
    <div>
      <NotFound />
    </div>
  )
}

export default NotFoundPage
