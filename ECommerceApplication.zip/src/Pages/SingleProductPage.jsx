import React from 'react'
import SingleProduct from '../Components/SingleProductComponent/SingleProduct'

const SingleProductPage = () => {
  return (
    <div>
      <SingleProduct />
    </div>
  )
}

export default SingleProductPage
