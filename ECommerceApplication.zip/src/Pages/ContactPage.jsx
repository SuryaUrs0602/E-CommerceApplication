import React from 'react'
import Contact from '../Components/ContactComponent/Contact'

const ContactPage = () => {
  return (
    <div>
      <Contact />
    </div>
  )
}

export default ContactPage
