import React from 'react'
import About from '../Components/AboutComponent/About';

const AboutPage = () => {
  return (
    <div>
      <About />
    </div>
  )
}

export default AboutPage
