import React from 'react'
import Home from '../Components/HomeComponent/Home'

const HomePage = () => {
  return (
    <div>
      <Home />
    </div>
  )
}

export default HomePage
